package com.example.carapp5.data

data class CarItem(val manufacturer: String?, val model: String?, val price: Int?)
